<?php
// Verificar si el formulario se envió
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Incluir el archivo de configuración de la base de datos
    require_once "conexion.php";
    
    // Definir las variables e inicializarlas con valores vacíos
    $usuario = $contrasena = $confirmar_contrasena = "";
    $usuario_err = $contrasena_err = $confirmar_contrasena_err = "";
    
    // Procesar los datos del formulario cuando se envía el formulario
    // Verificar el nombre de usuario
    if (empty(trim($_POST["usuario"]))) {
        $usuario_err = "Por favor ingrese un nombre de usuario.";
    } else {
        $usuario = trim($_POST["usuario"]);
    }
    
    // Verificar la contraseña
    if (empty(trim($_POST["contrasena"]))) {
        $contrasena_err = "Por favor ingrese una contraseña.";
    } elseif (strlen(trim($_POST["contrasena"])) < 6) {
        $contrasena_err = "La contraseña debe tener al menos 6 caracteres.";
    } else {
        $contrasena = trim($_POST["contrasena"]);
    }
    
    // Verificar la confirmación de la contraseña
    if (empty(trim($_POST["confirmar_contrasena"]))) {
        $confirmar_contrasena_err = "Por favor confirme la contraseña.";
    } else {
        $confirmar_contrasena = trim($_POST["confirmar_contrasena"]);
        if (empty($contrasena_err) && ($contrasena != $confirmar_contrasena)) {
            $confirmar_contrasena_err = "Las contraseñas no coinciden.";
        }
    }
    
    // Verificar errores de entrada antes de insertar en la base de datos
    if (empty($usuario_err) && empty($contrasena_err) && empty($confirmar_contrasena_err)) {
        // Preparar una declaración de inserción
        $sql = "INSERT INTO usuarios (usuario, contrasena) VALUES (?, ?)";
        
        if ($stmt = mysqli_prepare($link, $sql)) {
            // Vincular variables a la declaración preparada como parámetros
            mysqli_stmt_bind_param($stmt, "ss", $param_usuario, $param_contrasena);
            
            // Establecer parámetros
            $param_usuario = $usuario;
            $param_contrasena = password_hash($contrasena, PASSWORD_DEFAULT); // Hash de la contraseña
            
            // Ejecutar la declaración preparada
            if (mysqli_stmt_execute($stmt)) {
                // Redirigir al usuario a la página de inicio de sesión
                header("location: login.php");
            } else {
                echo "¡Vaya! Algo salió mal. Por favor, inténtalo de nuevo más tarde.";
            }

            // Cerrar la declaración
            mysqli_stmt_close($stmt);
        }
    }
    
    // Cerrar la conexión
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Keymasters</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Keymasters</h1>
        <nav>
            <a href="index.php">Inicio</a>
            <a href="about.php">Sobre Nosotros</a>
            <a href="services.php">Servicios</a>
            <a href="team.php">Equipo</a>
            <a href="contact.php">Contacto</a>
            <a href="blog.php">Blog</a>
        </nav>
    </header>
    <div class="container">
        <section>
            <h2>Registro</h2>
            <p>Por favor complete este formulario para crear una cuenta.</p>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group <?php echo !empty($usuario_err) ? 'has-error' : ''; ?>">
                    <label>Nombre de Usuario</label>
                    <input type="text" name="usuario" class="form-control" value="<?php echo $usuario; ?>">
                    <span class="help-block"><?php echo $usuario_err; ?></span>
                </div>    
                <div class="form-group <?php echo !empty($email_err) ? 'has-error' : ''; ?>">
                    <label>Correo Electrónico</label>
                    <input type="email" name="email" class="form-control" value="<?php echo $email; ?>">
                    <span class="help-block"><?php echo $email_err; ?></span>
                </div>
                <div class="form-group <?php echo !empty($contrasena_err) ? 'has-error' : ''; ?>">
                    <label>Contraseña</label>
                    <input type="password" name="contrasena" class="form-control" value="<?php echo $contrasena; ?>">
                    <span class="help-block"><?php echo $contrasena_err; ?></span>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="Enviar">
                    <input type="reset" class="btn btn-default" value="Restablecer">
                </div>
                <p>¿Ya tienes una cuenta? <a href="login.php">Inicia sesión aquí</a>.</p>
            </form>
        </section>
    </div>
    <footer>
        <p>&copy; 2024 Keymasters. Todos los derechos reservados.</p>
    </footer>
</body>
</html>