<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nosotros - Keymasters</title>
    <link rel="stylesheet" href="styles.css">
    <!-- Añadir biblioteca de iconos FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="logo.png" alt="Logo de Keymasters">
            <h1>Keymasters</h1>
        </div>
        <nav>
            <a href="index.php">Inicio</a>
            <div class="dropdown">
                <a href="about.php" class="dropbtn">Sobre Nosotros</a>
                <div class="dropdown-content">
                    <a href="history.php">Nuestra Historia</a>
                    <a href="mission.php">Nuestra Misión</a>
                    <a href="team.php">Nuestro Equipo</a>
                </div>
            </div>
            <div class="dropdown">
                <a href="services.php" class="dropbtn">Servicios</a>
                <div class="dropdown-content">
                    <a href="testimoniosdeclientes.php">Testimonios de Clientes</a> <!-- Enlace agregado -->
                    <a href="consulting.php">Consultoría</a>
                    <a href="development.php">Desarrollo</a>
                    <a href="support.php">Soporte</a>
                </div>
            </div>
            <a href="contact.php">Contacto</a>
            <a href="blog.php">Blog</a>
            <a href="login.php" class="login-link">Login</a> <!-- Enlace directo a la página de inicio de sesión -->
        </nav>
    </header>
    <div class="container">
        <section class="about-us">
            <h2>Sobre Nosotros</h2>
            <p>Keymasters es una empresa de consultoría informática dedicada a proporcionar soluciones tecnológicas avanzadas a empresas de todos los tamaños.</p>
        </section>
        
        <section class="values">
            <h2>Nuestros Valores</h2>
            <div class="value">
                <i class="fas fa-cogs"></i>
                <h3>Innovación</h3>
                <p>Nos esforzamos por ofrecer soluciones innovadoras y eficaces para satisfacer las necesidades de nuestros clientes.</p>
            </div>
            <div class="value">
                <i class="fas fa-users"></i>
                <h3>Compromiso</h3>
                <p>Nos comprometemos a proporcionar un servicio de calidad y a construir relaciones duraderas con nuestros clientes.</p>
            </div>
            <div class="value">
                <i class="fas fa-shield-alt"></i>
                <h3>Seguridad</h3>
                <p>La seguridad de nuestros clientes es nuestra máxima prioridad, y trabajamos diligentemente para proteger sus datos e infraestructuras.</p>
            </div>
        </section>

        <section class="team">
            <h2>Nuestro Equipo</h2>
            <div class="team-member">
                <img src="team-member1.jpg" alt="Miembro del Equipo 1">
                <h3>Juan Pérez</h3>
                <p>Director de Tecnología</p>
            </div>
            <div class="team-member">
                <img src="team-member2.jpg" alt="Miembro del Equipo 2">
                <h3>Elena Díaz</h3>
                <p>Gerente de Proyectos</p>
            </div>
            <div class="team-member">
                <img src="team-member3.jpg" alt="Miembro del Equipo 3">
                <h3>Marcos López</h3>
                <p>Especialista en Ciberseguridad</p>
            </div>
        </section>
    </div>
    <footer>
        <div class="social-media">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-linkedin-in"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
        <p>&copy; 2024 Keymasters. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
