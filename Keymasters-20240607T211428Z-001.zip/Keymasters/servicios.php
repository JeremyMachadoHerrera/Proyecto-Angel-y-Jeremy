<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Key Masters - Servicios</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body id="services">
    <header>
        <div class="container">
            <h1>Nuestros Servicios</h1>
            <nav>
            <a href="index.php">Inicio</a>
            <div class="dropdown">
                <a href="about.php" class="dropbtn">Sobre Nosotros</a>
                <div class="dropdown-content">
                    <a href="history.php">Nuestra Historia</a>
                    <a href="mission.php">Nuestra Misión</a>
                    <a href="team.php">Nuestro Equipo</a>
                </div>
            </div>
            <div class="dropdown">
                <a href="services.php" class="dropbtn">Servicios</a>
                <div class="dropdown-content">
                    <a href="consulting.php">Consultoría</a>
                    <a href="development.php">Desarrollo</a>
                    <a href="support.php">Soporte</a>
                </div>
            </div>
            <a href="contact.php">Contacto</a>
            <a href="blog.php">Blog</a>
        </nav>
        </div>
    </header>
    <section>
        <div class="container">
            <h2>Servicios Ofrecidos</h2>
            <div class="service">
                <a href="#">Servicio 1</a>
                <p>Descripción del Servicio 1</p>
            </div>
            <div class="service">
                <a href="#">Servicio 2</a>
                <p>Descripción del Servicio 2</p>
            </div>
            <div class="service">
                <a href="#">Servicio 3</a>
                <p>Descripción del Servicio 3</p>
            </div>
            <!-- Agrega más servicios según sea necesario -->
        </div>
    </section>
    <footer>
        <div class="container">
            <p>&copy; 2024 Key Masters - Todos los derechos reservados</p>
        </div>
    </footer>
</body>
</html>
